from .a03_m.a03 import A03
class A02:
    def __init__(self):
        print("A02 class is to test on making a class")
    def purpose(self):
        print("How long it is to make use of purpose function?")
    def use_A03(self):
        a3 = A03()
        a3.purpose()
        print("use A03 from a03 in a03_m")
