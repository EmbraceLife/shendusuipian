from ..other_funcs import for_a03_m

class A03:
    def __init__(self):
        print("creating a A03 object")
    def purpose(self):
        print("test dot")
    def use_a02(self):
        for_a03_m()
