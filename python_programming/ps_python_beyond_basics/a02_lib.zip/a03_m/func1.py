def use_all_():
    print("why use __all__?")
    print("regulate import * 的内容")
