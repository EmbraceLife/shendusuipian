def use_all_how():
    print("import exactly what to use")
    print("make a __all__ list of strings")
