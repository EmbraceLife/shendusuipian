def for_a03_m():
    print("I am a func from a02.py")
